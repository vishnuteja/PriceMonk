#!/usr/bin/perl

# PERL MODULES WE WILL BE USING
use DBI;
use DBD::mysql;

# HTTP HEADER
print "Content-type: text/html \n\n";

# CONFIG VARIABLES
$platform = "mysql";
$database = "shoppingSpider";
$host = "localhost";
$port = "3306";
$tablename = "products";
$user = "root";
$pw = "nivedita";

# DATA SOURCE NAME
$dsn = "dbi:mysql:$database:localhost:3306";

# PERL DBI CONNECT
$connect = DBI->connect($dsn, $user, $pw);

# PREPARE THE QUERY
$query = "SELECT * FROM products";
$query_handle = $connect->prepare($query);

# EXECUTE THE QUERY
$query_handle->execute();

# BIND TABLE COLUMNS TO VARIABLES
$query_handle->bind_columns(undef, \$productID, \$title, \$RelDate, \$category, \$imgUrl);

# LOOP THROUGH RESULTS
while($query_handle->fetch()) {
   print "$productID, $title, $RelDate, $category, $imgUrl \n";
} 